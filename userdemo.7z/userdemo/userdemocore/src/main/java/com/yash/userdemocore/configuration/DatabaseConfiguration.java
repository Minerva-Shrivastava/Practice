package com.yash.userdemocore.configuration;

import java.util.Properties;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jndi.JndiTemplate;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBean;

import com.yash.userdemocore.modal.User;

/**
 * this class will be the core database configuration in the application it
 * reads the database properties from the jdbc.properties file placed in the
 * resources folder on classpath this class will have a method which creates and
 * returns a hibernate sessionFactory object on the basis of the configuration
 * provided
 * 
 * @Configuration Annotating a class with the @Configuration indicates that the
 *                class can be used by the Spring IoC container as a source of
 *                bean definitions.
 * @ComponentScan annotation is used with @Configuration to tell Spring the
 *                packages to scan for annotated components.
 * @PropertySource is used to externalize your configuration to a properties
 *                 file
 */
@Configuration
@ComponentScan({ "com.yash.ycmscore.configuration" })
@ComponentScan(basePackages = "com.yash")
@PropertySource(value = "classpath:resource/db.properties")
public class DatabaseConfiguration {

	/**
	 * this will be used to read the properties file in future this could be
	 * used to read the profile option from the arguments
	 * 
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private Environment environment;

	/**
	 * this method will give the session factory object
	 * 
	 * @return sessionFactory object which will be used to get the hibernate
	 *         session instance
	 */
	@Bean
	public LocalSessionFactoryBean sessionFactory() {

		LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
		sessionFactory.setDataSource(dataSource());
		sessionFactory.setPackagesToScan(new String[] { "com.yash.userdemocore.model" });
		// add your POJO classes to this method seperated by comma
		sessionFactory.setAnnotatedClasses(User.class);
		sessionFactory.setHibernateProperties(hibernateProperties());
		return sessionFactory;

	}

	/**
	 * this method will read the properties file from the location provided in
	 * the @PropertySource tag above the class
	 * 
	 * @return hibernate properties
	 */
	private Properties hibernateProperties() {

		Properties properties = new Properties();
		properties.put("hibernate.dialect", environment.getRequiredProperty("hibernate.dialect"));
		properties.put("hibernate.show_sql", environment.getRequiredProperty("hibernate.show_sql"));
		properties.put("hibernate.format_sql", environment.getRequiredProperty("hibernate.format_sql"));
		properties.put("hibernate.hbm2ddl.auto", "create");
		return properties;

	}

	/**
	 * this method will create the DataSource for the hibernate sessionFactory
	 * 
	 * @author ishan.juneja
	 * @return Datasource for which hibernate will provide connections
	 */
	
	@Bean
	
	public DriverManagerDataSource dataSource() {

		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		try {
			dataSource = (DriverManagerDataSource) new JndiTemplate().lookup("java:comp/env/jdbc/usersDB");
			System.out.println(dataSource.getUrl());
		} catch (NamingException e) {
			e.printStackTrace();
		}
		/*dataSource.setUrl(environment.getProperty("jdbc.url"));
		dataSource.setUsername(environment.getProperty("jdbc.username"));
		dataSource.setPassword(environment.getProperty("jdbc.password"));
		dataSource.setDriverClassName(environment.getProperty("jdbc.drivername"));*/
		return dataSource;

	}

	/**
	 * this method will give the hibernate transaction manager
	 * 
	 * @param SessionFactory
	 *            for which session factory will hibernate maintain the
	 *            transaction
	 * @return TransactionManager for the Sessions of the SessionFactory passed
	 * @Bean is a method-level annotation and a direct analog of the XML <bean/>
	 *       element. When JavaConfig encounters such a method, it will execute
	 *       that method and register the return value as a bean within a
	 *       BeanFactory
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Bean
	@Autowired
	public HibernateTransactionManager transactionManager(SessionFactory s) {

		HibernateTransactionManager txManager = new HibernateTransactionManager();
		txManager.setSessionFactory(s);
		return txManager;

	}

}
