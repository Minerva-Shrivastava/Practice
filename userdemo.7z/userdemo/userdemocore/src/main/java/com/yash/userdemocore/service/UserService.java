package com.yash.userdemocore.service;

import java.util.List;

import com.yash.userdemocore.modal.User;

/**
 * this is the service interface for User related operations such as create,
 * List users, update and delete a user
 * 
 * @author minerva.shrivastava
 *
 */
public interface UserService {

	/**
	 * this method will be used to pass a user to the userDAO
	 * 
	 * @param user
	 *            to be saved in the database
	 * @return true if user added successfully or false if their is some error
	 *         saving the object
	 */
	public boolean add(User user);

	/**
	 * this method will be used to pass the user to the userDAO to be updated in
	 * the database
	 * 
	 * @param user
	 *            to be updated
	 * @return true if update is successful or false if the update is
	 *         unsuccessful
	 */
	public boolean update(User user);

	/**
	 * this method will be used to pass the id of the user to be deleted to the
	 * userDAO
	 * 
	 * @param id
	 *            of the user to be deleted
	 * @return true if delete operation is successful and false if delete
	 *         operation is unsuccessful
	 */
	public boolean delete(int id);

	/**
	 * this method will return a list of all the users in the database
	 * 
	 * @return a list of all the users in the database
	 */
	public List<User> list();

}
