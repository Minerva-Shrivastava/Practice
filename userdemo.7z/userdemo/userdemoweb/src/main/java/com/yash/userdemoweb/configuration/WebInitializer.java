package com.yash.userdemoweb.configuration;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

/**
 * 
 * this class will be the Web initializer of the application. it will configure
 * the application on the basis of the configurations provided in the
 * application

 * @author minerva.shrivastava
 *
 */
public class WebInitializer extends AbstractAnnotationConfigDispatcherServletInitializer{

	 
	/**
	 * this method will give the list of all the configuration classes passed to
	 * it
	 */
	@Override
	protected Class<?>[] getRootConfigClasses() {
		return new Class[] { WebConfiguration.class };
	}

	@Override
	protected Class<?>[] getServletConfigClasses() {
		return null;
	}

	/**
	 * this method will set the servlet mappings in the application
	 */
	@Override
	protected String[] getServletMappings() {
		return new String[] {"/"};
	}

}
