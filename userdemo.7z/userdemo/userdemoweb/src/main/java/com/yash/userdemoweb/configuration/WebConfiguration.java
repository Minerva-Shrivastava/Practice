package com.yash.userdemoweb.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * this class will contain the web configuration for the YCMS application
 * 
 * @author minerva.shrivastava
 * 
 * @Configuration Annotating a class with the @Configuration indicates that the
 *                class can be used by the Spring IoC container as a source of
 *                bean definitions.
 * @ComponentScan annotation is used with @Configuration to tell Spring the
 *                packages to scan for annotated components.
 * @EnableWebMvc is equivalent to <mvc:annotation-driven /> in XML. It enables
 *               support for @Controller-annotated classes that
 *               use @RequestMapping to map incoming requests to a certain
 *               method.
 */
@Configuration
@EnableWebMvc
@ComponentScan("com.yash")
public class WebConfiguration extends WebMvcConfigurerAdapter{

	
}
