package com.yash.excelpoc.model;

public class User {

	private int id;
	private String name;
	private int userId;
	
	public User() {
		super();
	}
	public User(int id, String name, int salary) {
		super();
		this.id = id;
		this.name = name;
		this.userId = salary;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	
	
}
