package com.yash.excelpoc.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.yash.excelpoc.model.User;

@RestController
public class UserExcelController {

	@RequestMapping(value="/processExcel" , method = RequestMethod.POST)
	public ModelAndView processExcel(Model model , @RequestParam("excelfile") MultipartFile excelfile ) {
		
		List<User> userList = new ArrayList<User>();
		int i = 0;
		try {
			HSSFWorkbook workbook= new HSSFWorkbook(excelfile.getInputStream());
			HSSFSheet worksheet = workbook.getSheetAt(0);
			while(i<= worksheet.getLastRowNum()) {
				User user = new User();
				HSSFRow row = worksheet.getRow(i++);
				user.setId((int)row.getCell(0).getNumericCellValue());
				user.setName(row.getCell(1).getStringCellValue());
				user.setUserId((int)row.getCell(2).getNumericCellValue());
				userList.add(user);
			}
			workbook.close();
			model.addAttribute("UserList", userList);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return new ModelAndView("welcome");
	}
}
